﻿namespace project3
{
    partial class DegreesInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblDegree = new System.Windows.Forms.Label();
            this.lblDTitle = new System.Windows.Forms.Label();
            this.lblConcent = new System.Windows.Forms.Label();
            this.lbxConcent = new System.Windows.Forms.ListBox();
            this.tbDesc = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblDegree
            // 
            this.lblDegree.AutoSize = true;
            this.lblDegree.Location = new System.Drawing.Point(24, 34);
            this.lblDegree.Name = "lblDegree";
            this.lblDegree.Size = new System.Drawing.Size(35, 13);
            this.lblDegree.TabIndex = 0;
            this.lblDegree.Text = "label1";
            // 
            // lblDTitle
            // 
            this.lblDTitle.AutoSize = true;
            this.lblDTitle.Location = new System.Drawing.Point(24, 93);
            this.lblDTitle.Name = "lblDTitle";
            this.lblDTitle.Size = new System.Drawing.Size(35, 13);
            this.lblDTitle.TabIndex = 1;
            this.lblDTitle.Text = "label1";
            // 
            // lblConcent
            // 
            this.lblConcent.AutoSize = true;
            this.lblConcent.Location = new System.Drawing.Point(364, 270);
            this.lblConcent.Name = "lblConcent";
            this.lblConcent.Size = new System.Drawing.Size(72, 13);
            this.lblConcent.TabIndex = 5;
            this.lblConcent.Text = "Concetrations";
            // 
            // lbxConcent
            // 
            this.lbxConcent.BackColor = System.Drawing.SystemColors.Control;
            this.lbxConcent.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lbxConcent.FormattingEnabled = true;
            this.lbxConcent.Location = new System.Drawing.Point(244, 296);
            this.lbxConcent.Name = "lbxConcent";
            this.lbxConcent.Size = new System.Drawing.Size(320, 117);
            this.lbxConcent.TabIndex = 7;
            // 
            // tbDesc
            // 
            this.tbDesc.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbDesc.Location = new System.Drawing.Point(27, 119);
            this.tbDesc.Multiline = true;
            this.tbDesc.Name = "tbDesc";
            this.tbDesc.ReadOnly = true;
            this.tbDesc.Size = new System.Drawing.Size(537, 72);
            this.tbDesc.TabIndex = 8;
            // 
            // DegreesInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(709, 450);
            this.Controls.Add(this.tbDesc);
            this.Controls.Add(this.lbxConcent);
            this.Controls.Add(this.lblConcent);
            this.Controls.Add(this.lblDTitle);
            this.Controls.Add(this.lblDegree);
            this.Name = "DegreesInfo";
            this.Text = "DegreesInfo";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblDegree;
        private System.Windows.Forms.Label lblDTitle;
        private System.Windows.Forms.Label lblConcent;
        private System.Windows.Forms.ListBox lbxConcent;
        private System.Windows.Forms.TextBox tbDesc;
    }
}