﻿using RESTUtility;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project3
{
    public partial class DegreesInfo : Form
    {

        public DegreesInfo()
        {
            InitializeComponent();
        }

        public void setLabel(string name, int num)
        {
            if(num == 1)
            {
                lblDegree.Text = name;
            }
            else if(num == 2)
            {
                lblDTitle.Text = name;
            }
            else if (num == 3)
            {
                tbDesc.Text = name;
            }
            
        }

        public void addToList(List<string> concents)
        {
            if(lbxConcent.Items.Count > 0)
            {
                lbxConcent.Items.Clear();
            }

            foreach (string item in concents)
            {
                lbxConcent.Items.Add(item);
            }
        }

    }
}
