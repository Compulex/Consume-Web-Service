﻿namespace project3
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tcEverything = new System.Windows.Forms.TabControl();
            this.tp_About = new System.Windows.Forms.TabPage();
            this.tbQuote = new System.Windows.Forms.TextBox();
            this.tbDesc = new System.Windows.Forms.TextBox();
            this.lblQAuthor = new System.Windows.Forms.Label();
            this.lblDesc = new System.Windows.Forms.Label();
            this.lblTitle = new System.Windows.Forms.Label();
            this.tp_Degrees = new System.Windows.Forms.TabPage();
            this.lblCert = new System.Windows.Forms.Label();
            this.lblGrad = new System.Windows.Forms.Label();
            this.btnNSA = new System.Windows.Forms.Button();
            this.btnHCI = new System.Windows.Forms.Button();
            this.btnIST = new System.Windows.Forms.Button();
            this.btnCIT = new System.Windows.Forms.Button();
            this.btnHCC = new System.Windows.Forms.Button();
            this.btnWMC = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.ugTitle = new System.Windows.Forms.Label();
            this.tp_Minors = new System.Windows.Forms.TabPage();
            this.lblNote = new System.Windows.Forms.Label();
            this.lbxCourses = new System.Windows.Forms.ListBox();
            this.tbMDesc = new System.Windows.Forms.TextBox();
            this.lblMin = new System.Windows.Forms.Label();
            this.lblMName = new System.Windows.Forms.Label();
            this.hsbMinors = new System.Windows.Forms.HScrollBar();
            this.tp_Employ = new System.Windows.Forms.TabPage();
            this.tbCareers = new System.Windows.Forms.TextBox();
            this.tbEmployers = new System.Windows.Forms.TextBox();
            this.lblC = new System.Windows.Forms.Label();
            this.lblE = new System.Windows.Forms.Label();
            this.dgvCoop = new System.Windows.Forms.DataGridView();
            this.Employer = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Degree = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.City = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Term = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblTable = new System.Windows.Forms.Label();
            this.dgvEmploy = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Title = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.StartDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnTable = new System.Windows.Forms.Button();
            this.lblCoopTitle = new System.Windows.Forms.Label();
            this.tbCoopDesc = new System.Windows.Forms.TextBox();
            this.lblETitle = new System.Windows.Forms.Label();
            this.tbEmployDesc = new System.Windows.Forms.TextBox();
            this.lblMTitle = new System.Windows.Forms.Label();
            this.tp_Ppl = new System.Windows.Forms.TabPage();
            this.lblFbk = new System.Windows.Forms.Label();
            this.lblTwitter = new System.Windows.Forms.Label();
            this.lblWebsite = new System.Windows.Forms.Label();
            this.lblOffice = new System.Windows.Forms.Label();
            this.lblIntArea = new System.Windows.Forms.Label();
            this.lblPTitle = new System.Windows.Forms.Label();
            this.lblTagline = new System.Windows.Forms.Label();
            this.lblUsername = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.btnSwitch = new System.Windows.Forms.Button();
            this.lbxPeople = new System.Windows.Forms.ListBox();
            this.pbPeople = new System.Windows.Forms.PictureBox();
            this.tp_Research = new System.Windows.Forms.TabPage();
            this.lvCitate = new System.Windows.Forms.ListView();
            this.lblRDesc = new System.Windows.Forms.Label();
            this.lbxFacArea = new System.Windows.Forms.ListBox();
            this.btnRSwitch = new System.Windows.Forms.Button();
            this.lblReTitle = new System.Windows.Forms.Label();
            this.tp_Resources = new System.Windows.Forms.TabPage();
            this.tbAbroad = new System.Windows.Forms.TextBox();
            this.lblSub = new System.Windows.Forms.Label();
            this.btnCoop = new System.Windows.Forms.Button();
            this.btnSAm = new System.Windows.Forms.Button();
            this.btnSS = new System.Windows.Forms.Button();
            this.lblFm = new System.Windows.Forms.Label();
            this.lblTL = new System.Windows.Forms.Label();
            this.lblSAb = new System.Windows.Forms.Label();
            this.lblRTitle = new System.Windows.Forms.Label();
            this.tp_News = new System.Windows.Forms.TabPage();
            this.vsbNews = new System.Windows.Forms.VScrollBar();
            this.tbNDesc = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lblNDate = new System.Windows.Forms.Label();
            this.lblNTitle = new System.Windows.Forms.Label();
            this.tp_Footer = new System.Windows.Forms.TabPage();
            this.lblCopyHtml = new System.Windows.Forms.Label();
            this.lblCopyright = new System.Windows.Forms.Label();
            this.lblTAuthor = new System.Windows.Forms.Label();
            this.llblLab = new System.Windows.Forms.LinkLabel();
            this.llblSupport = new System.Windows.Forms.LinkLabel();
            this.llblAbout = new System.Windows.Forms.LinkLabel();
            this.llblApply = new System.Windows.Forms.LinkLabel();
            this.lblTweet = new System.Windows.Forms.Label();
            this.lblSTitle = new System.Windows.Forms.Label();
            this.tcEverything.SuspendLayout();
            this.tp_About.SuspendLayout();
            this.tp_Degrees.SuspendLayout();
            this.tp_Minors.SuspendLayout();
            this.tp_Employ.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCoop)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEmploy)).BeginInit();
            this.tp_Ppl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbPeople)).BeginInit();
            this.tp_Research.SuspendLayout();
            this.tp_Resources.SuspendLayout();
            this.tp_News.SuspendLayout();
            this.tp_Footer.SuspendLayout();
            this.SuspendLayout();
            // 
            // tcEverything
            // 
            this.tcEverything.Controls.Add(this.tp_About);
            this.tcEverything.Controls.Add(this.tp_Degrees);
            this.tcEverything.Controls.Add(this.tp_Minors);
            this.tcEverything.Controls.Add(this.tp_Employ);
            this.tcEverything.Controls.Add(this.tp_Ppl);
            this.tcEverything.Controls.Add(this.tp_Research);
            this.tcEverything.Controls.Add(this.tp_Resources);
            this.tcEverything.Controls.Add(this.tp_News);
            this.tcEverything.Controls.Add(this.tp_Footer);
            this.tcEverything.Location = new System.Drawing.Point(12, 10);
            this.tcEverything.Name = "tcEverything";
            this.tcEverything.SelectedIndex = 0;
            this.tcEverything.Size = new System.Drawing.Size(944, 595);
            this.tcEverything.TabIndex = 0;
            this.tcEverything.SelectedIndexChanged += new System.EventHandler(this.tcEverything_SelectedIndexChanged);
            // 
            // tp_About
            // 
            this.tp_About.Controls.Add(this.tbQuote);
            this.tp_About.Controls.Add(this.tbDesc);
            this.tp_About.Controls.Add(this.lblQAuthor);
            this.tp_About.Controls.Add(this.lblDesc);
            this.tp_About.Controls.Add(this.lblTitle);
            this.tp_About.Location = new System.Drawing.Point(4, 22);
            this.tp_About.Name = "tp_About";
            this.tp_About.Padding = new System.Windows.Forms.Padding(3);
            this.tp_About.Size = new System.Drawing.Size(936, 569);
            this.tp_About.TabIndex = 0;
            this.tp_About.Text = "About";
            this.tp_About.UseVisualStyleBackColor = true;
            // 
            // tbQuote
            // 
            this.tbQuote.BackColor = System.Drawing.SystemColors.Window;
            this.tbQuote.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbQuote.Location = new System.Drawing.Point(44, 234);
            this.tbQuote.Multiline = true;
            this.tbQuote.Name = "tbQuote";
            this.tbQuote.ReadOnly = true;
            this.tbQuote.Size = new System.Drawing.Size(648, 58);
            this.tbQuote.TabIndex = 5;
            this.tbQuote.Text = "tweet";
            // 
            // tbDesc
            // 
            this.tbDesc.BackColor = System.Drawing.SystemColors.Window;
            this.tbDesc.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbDesc.Location = new System.Drawing.Point(44, 86);
            this.tbDesc.Multiline = true;
            this.tbDesc.Name = "tbDesc";
            this.tbDesc.ReadOnly = true;
            this.tbDesc.Size = new System.Drawing.Size(648, 119);
            this.tbDesc.TabIndex = 4;
            this.tbDesc.Text = "desc";
            // 
            // lblQAuthor
            // 
            this.lblQAuthor.AutoSize = true;
            this.lblQAuthor.Location = new System.Drawing.Point(41, 321);
            this.lblQAuthor.Name = "lblQAuthor";
            this.lblQAuthor.Size = new System.Drawing.Size(35, 13);
            this.lblQAuthor.TabIndex = 3;
            this.lblQAuthor.Text = "label2";
            // 
            // lblDesc
            // 
            this.lblDesc.AutoSize = true;
            this.lblDesc.Location = new System.Drawing.Point(41, 100);
            this.lblDesc.Name = "lblDesc";
            this.lblDesc.Size = new System.Drawing.Size(0, 13);
            this.lblDesc.TabIndex = 1;
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Location = new System.Drawing.Point(41, 49);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(35, 13);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "label1";
            // 
            // tp_Degrees
            // 
            this.tp_Degrees.Controls.Add(this.lblCert);
            this.tp_Degrees.Controls.Add(this.lblGrad);
            this.tp_Degrees.Controls.Add(this.btnNSA);
            this.tp_Degrees.Controls.Add(this.btnHCI);
            this.tp_Degrees.Controls.Add(this.btnIST);
            this.tp_Degrees.Controls.Add(this.btnCIT);
            this.tp_Degrees.Controls.Add(this.btnHCC);
            this.tp_Degrees.Controls.Add(this.btnWMC);
            this.tp_Degrees.Controls.Add(this.label1);
            this.tp_Degrees.Controls.Add(this.ugTitle);
            this.tp_Degrees.Location = new System.Drawing.Point(4, 22);
            this.tp_Degrees.Name = "tp_Degrees";
            this.tp_Degrees.Padding = new System.Windows.Forms.Padding(3);
            this.tp_Degrees.Size = new System.Drawing.Size(936, 569);
            this.tp_Degrees.TabIndex = 1;
            this.tp_Degrees.Text = "Degrees";
            this.tp_Degrees.UseVisualStyleBackColor = true;
            // 
            // lblCert
            // 
            this.lblCert.AutoSize = true;
            this.lblCert.Location = new System.Drawing.Point(254, 514);
            this.lblCert.Name = "lblCert";
            this.lblCert.Size = new System.Drawing.Size(35, 13);
            this.lblCert.TabIndex = 9;
            this.lblCert.Text = "label3";
            this.lblCert.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblGrad
            // 
            this.lblGrad.AutoSize = true;
            this.lblGrad.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGrad.Location = new System.Drawing.Point(372, 489);
            this.lblGrad.Name = "lblGrad";
            this.lblGrad.Size = new System.Drawing.Size(41, 13);
            this.lblGrad.TabIndex = 8;
            this.lblGrad.Text = "label3";
            this.lblGrad.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnNSA
            // 
            this.btnNSA.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNSA.Location = new System.Drawing.Point(620, 298);
            this.btnNSA.Name = "btnNSA";
            this.btnNSA.Size = new System.Drawing.Size(159, 157);
            this.btnNSA.TabIndex = 7;
            this.btnNSA.Text = "NSA";
            this.btnNSA.UseVisualStyleBackColor = true;
            // 
            // btnHCI
            // 
            this.btnHCI.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHCI.Location = new System.Drawing.Point(375, 298);
            this.btnHCI.Name = "btnHCI";
            this.btnHCI.Size = new System.Drawing.Size(159, 157);
            this.btnHCI.TabIndex = 6;
            this.btnHCI.Text = "HCI";
            this.btnHCI.UseVisualStyleBackColor = true;
            // 
            // btnIST
            // 
            this.btnIST.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIST.Location = new System.Drawing.Point(130, 298);
            this.btnIST.Name = "btnIST";
            this.btnIST.Size = new System.Drawing.Size(159, 157);
            this.btnIST.TabIndex = 5;
            this.btnIST.Text = "IST";
            this.btnIST.UseVisualStyleBackColor = true;
            // 
            // btnCIT
            // 
            this.btnCIT.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCIT.Location = new System.Drawing.Point(620, 61);
            this.btnCIT.Name = "btnCIT";
            this.btnCIT.Size = new System.Drawing.Size(159, 157);
            this.btnCIT.TabIndex = 4;
            this.btnCIT.Text = "CIT";
            this.btnCIT.UseVisualStyleBackColor = true;
            // 
            // btnHCC
            // 
            this.btnHCC.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHCC.Location = new System.Drawing.Point(375, 61);
            this.btnHCC.Name = "btnHCC";
            this.btnHCC.Size = new System.Drawing.Size(159, 157);
            this.btnHCC.TabIndex = 3;
            this.btnHCC.Text = "HCC";
            this.btnHCC.UseVisualStyleBackColor = true;
            // 
            // btnWMC
            // 
            this.btnWMC.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnWMC.Location = new System.Drawing.Point(130, 61);
            this.btnWMC.Name = "btnWMC";
            this.btnWMC.Size = new System.Drawing.Size(159, 157);
            this.btnWMC.TabIndex = 2;
            this.btnWMC.Text = "WMC";
            this.btnWMC.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(396, 263);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Our Graduate Degrees";
            // 
            // ugTitle
            // 
            this.ugTitle.AutoSize = true;
            this.ugTitle.Location = new System.Drawing.Point(393, 24);
            this.ugTitle.Name = "ugTitle";
            this.ugTitle.Size = new System.Drawing.Size(141, 13);
            this.ugTitle.TabIndex = 0;
            this.ugTitle.Text = "Our Undergraduate Degrees";
            // 
            // tp_Minors
            // 
            this.tp_Minors.Controls.Add(this.lblNote);
            this.tp_Minors.Controls.Add(this.lbxCourses);
            this.tp_Minors.Controls.Add(this.tbMDesc);
            this.tp_Minors.Controls.Add(this.lblMin);
            this.tp_Minors.Controls.Add(this.lblMName);
            this.tp_Minors.Controls.Add(this.hsbMinors);
            this.tp_Minors.Location = new System.Drawing.Point(4, 22);
            this.tp_Minors.Name = "tp_Minors";
            this.tp_Minors.Padding = new System.Windows.Forms.Padding(3);
            this.tp_Minors.Size = new System.Drawing.Size(936, 569);
            this.tp_Minors.TabIndex = 2;
            this.tp_Minors.Text = "Minors";
            this.tp_Minors.UseVisualStyleBackColor = true;
            // 
            // lblNote
            // 
            this.lblNote.AutoSize = true;
            this.lblNote.Location = new System.Drawing.Point(19, 418);
            this.lblNote.Name = "lblNote";
            this.lblNote.Size = new System.Drawing.Size(29, 13);
            this.lblNote.TabIndex = 5;
            this.lblNote.Text = "label";
            // 
            // lbxCourses
            // 
            this.lbxCourses.FormattingEnabled = true;
            this.lbxCourses.Location = new System.Drawing.Point(620, 73);
            this.lbxCourses.Name = "lbxCourses";
            this.lbxCourses.Size = new System.Drawing.Size(290, 238);
            this.lbxCourses.TabIndex = 4;
            // 
            // tbMDesc
            // 
            this.tbMDesc.BackColor = System.Drawing.SystemColors.Window;
            this.tbMDesc.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbMDesc.Location = new System.Drawing.Point(22, 158);
            this.tbMDesc.Multiline = true;
            this.tbMDesc.Name = "tbMDesc";
            this.tbMDesc.ReadOnly = true;
            this.tbMDesc.Size = new System.Drawing.Size(374, 153);
            this.tbMDesc.TabIndex = 3;
            // 
            // lblMin
            // 
            this.lblMin.AutoSize = true;
            this.lblMin.Location = new System.Drawing.Point(19, 97);
            this.lblMin.Name = "lblMin";
            this.lblMin.Size = new System.Drawing.Size(29, 13);
            this.lblMin.TabIndex = 2;
            this.lblMin.Text = "label";
            // 
            // lblMName
            // 
            this.lblMName.AutoSize = true;
            this.lblMName.Location = new System.Drawing.Point(19, 37);
            this.lblMName.Name = "lblMName";
            this.lblMName.Size = new System.Drawing.Size(29, 13);
            this.lblMName.TabIndex = 1;
            this.lblMName.Text = "label";
            // 
            // hsbMinors
            // 
            this.hsbMinors.Location = new System.Drawing.Point(22, 530);
            this.hsbMinors.Name = "hsbMinors";
            this.hsbMinors.Size = new System.Drawing.Size(888, 17);
            this.hsbMinors.TabIndex = 0;
            this.hsbMinors.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hScrollBar1_Scroll);
            // 
            // tp_Employ
            // 
            this.tp_Employ.Controls.Add(this.tbCareers);
            this.tp_Employ.Controls.Add(this.tbEmployers);
            this.tp_Employ.Controls.Add(this.lblC);
            this.tp_Employ.Controls.Add(this.lblE);
            this.tp_Employ.Controls.Add(this.dgvCoop);
            this.tp_Employ.Controls.Add(this.lblTable);
            this.tp_Employ.Controls.Add(this.dgvEmploy);
            this.tp_Employ.Controls.Add(this.btnTable);
            this.tp_Employ.Controls.Add(this.lblCoopTitle);
            this.tp_Employ.Controls.Add(this.tbCoopDesc);
            this.tp_Employ.Controls.Add(this.lblETitle);
            this.tp_Employ.Controls.Add(this.tbEmployDesc);
            this.tp_Employ.Controls.Add(this.lblMTitle);
            this.tp_Employ.Location = new System.Drawing.Point(4, 22);
            this.tp_Employ.Name = "tp_Employ";
            this.tp_Employ.Padding = new System.Windows.Forms.Padding(3);
            this.tp_Employ.Size = new System.Drawing.Size(936, 569);
            this.tp_Employ.TabIndex = 3;
            this.tp_Employ.Text = "Employment";
            this.tp_Employ.UseVisualStyleBackColor = true;
            // 
            // tbCareers
            // 
            this.tbCareers.BackColor = System.Drawing.SystemColors.Window;
            this.tbCareers.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbCareers.Location = new System.Drawing.Point(94, 304);
            this.tbCareers.Name = "tbCareers";
            this.tbCareers.ReadOnly = true;
            this.tbCareers.Size = new System.Drawing.Size(723, 13);
            this.tbCareers.TabIndex = 14;
            this.tbCareers.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbEmployers
            // 
            this.tbEmployers.BackColor = System.Drawing.SystemColors.Window;
            this.tbEmployers.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbEmployers.Location = new System.Drawing.Point(140, 236);
            this.tbEmployers.Name = "tbEmployers";
            this.tbEmployers.ReadOnly = true;
            this.tbEmployers.Size = new System.Drawing.Size(621, 13);
            this.tbEmployers.TabIndex = 13;
            this.tbEmployers.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblC
            // 
            this.lblC.AutoSize = true;
            this.lblC.Location = new System.Drawing.Point(421, 288);
            this.lblC.Name = "lblC";
            this.lblC.Size = new System.Drawing.Size(35, 13);
            this.lblC.TabIndex = 12;
            this.lblC.Text = "label6";
            // 
            // lblE
            // 
            this.lblE.AutoSize = true;
            this.lblE.Location = new System.Drawing.Point(421, 217);
            this.lblE.Name = "lblE";
            this.lblE.Size = new System.Drawing.Size(35, 13);
            this.lblE.TabIndex = 11;
            this.lblE.Text = "label5";
            // 
            // dgvCoop
            // 
            this.dgvCoop.AllowUserToAddRows = false;
            this.dgvCoop.AllowUserToDeleteRows = false;
            this.dgvCoop.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCoop.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Employer,
            this.Degree,
            this.City,
            this.Term});
            this.dgvCoop.Location = new System.Drawing.Point(6, 404);
            this.dgvCoop.Name = "dgvCoop";
            this.dgvCoop.ReadOnly = true;
            this.dgvCoop.Size = new System.Drawing.Size(662, 150);
            this.dgvCoop.TabIndex = 5;
            // 
            // Employer
            // 
            this.Employer.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Employer.HeaderText = "Employer";
            this.Employer.Name = "Employer";
            this.Employer.ReadOnly = true;
            this.Employer.Width = 75;
            // 
            // Degree
            // 
            this.Degree.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Degree.HeaderText = "Degree";
            this.Degree.Name = "Degree";
            this.Degree.ReadOnly = true;
            this.Degree.Width = 67;
            // 
            // City
            // 
            this.City.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.City.HeaderText = "City";
            this.City.Name = "City";
            this.City.ReadOnly = true;
            this.City.Width = 49;
            // 
            // Term
            // 
            this.Term.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Term.HeaderText = "Term";
            this.Term.Name = "Term";
            this.Term.ReadOnly = true;
            this.Term.Width = 56;
            // 
            // lblTable
            // 
            this.lblTable.AutoSize = true;
            this.lblTable.Location = new System.Drawing.Point(6, 377);
            this.lblTable.Name = "lblTable";
            this.lblTable.Size = new System.Drawing.Size(35, 13);
            this.lblTable.TabIndex = 9;
            this.lblTable.Text = "label5";
            // 
            // dgvEmploy
            // 
            this.dgvEmploy.AllowUserToAddRows = false;
            this.dgvEmploy.AllowUserToDeleteRows = false;
            this.dgvEmploy.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvEmploy.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.Title,
            this.StartDate});
            this.dgvEmploy.Location = new System.Drawing.Point(6, 404);
            this.dgvEmploy.Name = "dgvEmploy";
            this.dgvEmploy.ReadOnly = true;
            this.dgvEmploy.Size = new System.Drawing.Size(892, 150);
            this.dgvEmploy.TabIndex = 8;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn1.HeaderText = "Employer";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 75;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn2.HeaderText = "Degree";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Width = 67;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn3.HeaderText = "City";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Width = 49;
            // 
            // Title
            // 
            this.Title.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Title.HeaderText = "Title";
            this.Title.Name = "Title";
            this.Title.ReadOnly = true;
            this.Title.Width = 52;
            // 
            // StartDate
            // 
            this.StartDate.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.StartDate.HeaderText = "StartDate";
            this.StartDate.Name = "StartDate";
            this.StartDate.ReadOnly = true;
            this.StartDate.Width = 77;
            // 
            // btnTable
            // 
            this.btnTable.Location = new System.Drawing.Point(9, 342);
            this.btnTable.Name = "btnTable";
            this.btnTable.Size = new System.Drawing.Size(133, 23);
            this.btnTable.TabIndex = 7;
            this.btnTable.Text = "Show Coop Table";
            this.btnTable.UseVisualStyleBackColor = true;
            this.btnTable.Click += new System.EventHandler(this.btnTable_Click);
            // 
            // lblCoopTitle
            // 
            this.lblCoopTitle.AutoSize = true;
            this.lblCoopTitle.Location = new System.Drawing.Point(704, 53);
            this.lblCoopTitle.Name = "lblCoopTitle";
            this.lblCoopTitle.Size = new System.Drawing.Size(67, 13);
            this.lblCoopTitle.TabIndex = 4;
            this.lblCoopTitle.Text = "Content Title";
            // 
            // tbCoopDesc
            // 
            this.tbCoopDesc.BackColor = System.Drawing.SystemColors.Window;
            this.tbCoopDesc.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbCoopDesc.Location = new System.Drawing.Point(547, 69);
            this.tbCoopDesc.Multiline = true;
            this.tbCoopDesc.Name = "tbCoopDesc";
            this.tbCoopDesc.ReadOnly = true;
            this.tbCoopDesc.Size = new System.Drawing.Size(383, 143);
            this.tbCoopDesc.TabIndex = 3;
            this.tbCoopDesc.Text = "Content desc";
            this.tbCoopDesc.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblETitle
            // 
            this.lblETitle.AutoSize = true;
            this.lblETitle.Location = new System.Drawing.Point(148, 53);
            this.lblETitle.Name = "lblETitle";
            this.lblETitle.Size = new System.Drawing.Size(67, 13);
            this.lblETitle.TabIndex = 2;
            this.lblETitle.Text = "Content Title";
            // 
            // tbEmployDesc
            // 
            this.tbEmployDesc.BackColor = System.Drawing.SystemColors.Window;
            this.tbEmployDesc.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbEmployDesc.Location = new System.Drawing.Point(6, 69);
            this.tbEmployDesc.Multiline = true;
            this.tbEmployDesc.Name = "tbEmployDesc";
            this.tbEmployDesc.ReadOnly = true;
            this.tbEmployDesc.Size = new System.Drawing.Size(354, 115);
            this.tbEmployDesc.TabIndex = 1;
            this.tbEmployDesc.Text = "Content desc";
            this.tbEmployDesc.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblMTitle
            // 
            this.lblMTitle.AutoSize = true;
            this.lblMTitle.Location = new System.Drawing.Point(386, 15);
            this.lblMTitle.Name = "lblMTitle";
            this.lblMTitle.Size = new System.Drawing.Size(51, 13);
            this.lblMTitle.TabIndex = 0;
            this.lblMTitle.Text = "Intro Title";
            // 
            // tp_Ppl
            // 
            this.tp_Ppl.Controls.Add(this.lblFbk);
            this.tp_Ppl.Controls.Add(this.lblTwitter);
            this.tp_Ppl.Controls.Add(this.lblWebsite);
            this.tp_Ppl.Controls.Add(this.lblOffice);
            this.tp_Ppl.Controls.Add(this.lblIntArea);
            this.tp_Ppl.Controls.Add(this.lblPTitle);
            this.tp_Ppl.Controls.Add(this.lblTagline);
            this.tp_Ppl.Controls.Add(this.lblUsername);
            this.tp_Ppl.Controls.Add(this.lblName);
            this.tp_Ppl.Controls.Add(this.btnSwitch);
            this.tp_Ppl.Controls.Add(this.lbxPeople);
            this.tp_Ppl.Controls.Add(this.pbPeople);
            this.tp_Ppl.Location = new System.Drawing.Point(4, 22);
            this.tp_Ppl.Name = "tp_Ppl";
            this.tp_Ppl.Padding = new System.Windows.Forms.Padding(3);
            this.tp_Ppl.Size = new System.Drawing.Size(936, 569);
            this.tp_Ppl.TabIndex = 4;
            this.tp_Ppl.Text = "People";
            this.tp_Ppl.UseVisualStyleBackColor = true;
            // 
            // lblFbk
            // 
            this.lblFbk.AutoSize = true;
            this.lblFbk.Location = new System.Drawing.Point(648, 344);
            this.lblFbk.Name = "lblFbk";
            this.lblFbk.Size = new System.Drawing.Size(55, 13);
            this.lblFbk.TabIndex = 11;
            this.lblFbk.Text = "Facebook";
            // 
            // lblTwitter
            // 
            this.lblTwitter.AutoSize = true;
            this.lblTwitter.Location = new System.Drawing.Point(648, 305);
            this.lblTwitter.Name = "lblTwitter";
            this.lblTwitter.Size = new System.Drawing.Size(39, 13);
            this.lblTwitter.TabIndex = 10;
            this.lblTwitter.Text = "Twitter";
            // 
            // lblWebsite
            // 
            this.lblWebsite.AutoSize = true;
            this.lblWebsite.Location = new System.Drawing.Point(648, 266);
            this.lblWebsite.Name = "lblWebsite";
            this.lblWebsite.Size = new System.Drawing.Size(46, 13);
            this.lblWebsite.TabIndex = 9;
            this.lblWebsite.Text = "Website";
            // 
            // lblOffice
            // 
            this.lblOffice.AutoSize = true;
            this.lblOffice.Location = new System.Drawing.Point(648, 227);
            this.lblOffice.Name = "lblOffice";
            this.lblOffice.Size = new System.Drawing.Size(35, 13);
            this.lblOffice.TabIndex = 8;
            this.lblOffice.Text = "Office";
            // 
            // lblIntArea
            // 
            this.lblIntArea.AutoSize = true;
            this.lblIntArea.Location = new System.Drawing.Point(648, 188);
            this.lblIntArea.Name = "lblIntArea";
            this.lblIntArea.Size = new System.Drawing.Size(67, 13);
            this.lblIntArea.TabIndex = 7;
            this.lblIntArea.Text = "Interest Area";
            // 
            // lblPTitle
            // 
            this.lblPTitle.AutoSize = true;
            this.lblPTitle.Location = new System.Drawing.Point(648, 149);
            this.lblPTitle.Name = "lblPTitle";
            this.lblPTitle.Size = new System.Drawing.Size(27, 13);
            this.lblPTitle.TabIndex = 6;
            this.lblPTitle.Text = "Title";
            // 
            // lblTagline
            // 
            this.lblTagline.AutoSize = true;
            this.lblTagline.Location = new System.Drawing.Point(648, 110);
            this.lblTagline.Name = "lblTagline";
            this.lblTagline.Size = new System.Drawing.Size(42, 13);
            this.lblTagline.TabIndex = 5;
            this.lblTagline.Text = "Tagline";
            // 
            // lblUsername
            // 
            this.lblUsername.AutoSize = true;
            this.lblUsername.Location = new System.Drawing.Point(648, 71);
            this.lblUsername.Name = "lblUsername";
            this.lblUsername.Size = new System.Drawing.Size(55, 13);
            this.lblUsername.TabIndex = 4;
            this.lblUsername.Text = "Username";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(310, 35);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(35, 13);
            this.lblName.TabIndex = 3;
            this.lblName.Text = "Name";
            // 
            // btnSwitch
            // 
            this.btnSwitch.Location = new System.Drawing.Point(87, 25);
            this.btnSwitch.Name = "btnSwitch";
            this.btnSwitch.Size = new System.Drawing.Size(75, 23);
            this.btnSwitch.TabIndex = 2;
            this.btnSwitch.Text = "button1";
            this.btnSwitch.UseVisualStyleBackColor = true;
            this.btnSwitch.Click += new System.EventHandler(this.btnSwitch_Click);
            // 
            // lbxPeople
            // 
            this.lbxPeople.FormattingEnabled = true;
            this.lbxPeople.Location = new System.Drawing.Point(31, 73);
            this.lbxPeople.Name = "lbxPeople";
            this.lbxPeople.Size = new System.Drawing.Size(202, 290);
            this.lbxPeople.TabIndex = 1;
            this.lbxPeople.SelectedIndexChanged += new System.EventHandler(this.lbxPeople_SelectedIndexChanged);
            // 
            // pbPeople
            // 
            this.pbPeople.Location = new System.Drawing.Point(313, 73);
            this.pbPeople.Name = "pbPeople";
            this.pbPeople.Size = new System.Drawing.Size(262, 284);
            this.pbPeople.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbPeople.TabIndex = 0;
            this.pbPeople.TabStop = false;
            // 
            // tp_Research
            // 
            this.tp_Research.Controls.Add(this.lvCitate);
            this.tp_Research.Controls.Add(this.lblRDesc);
            this.tp_Research.Controls.Add(this.lbxFacArea);
            this.tp_Research.Controls.Add(this.btnRSwitch);
            this.tp_Research.Controls.Add(this.lblReTitle);
            this.tp_Research.Location = new System.Drawing.Point(4, 22);
            this.tp_Research.Name = "tp_Research";
            this.tp_Research.Padding = new System.Windows.Forms.Padding(3);
            this.tp_Research.Size = new System.Drawing.Size(936, 569);
            this.tp_Research.TabIndex = 5;
            this.tp_Research.Text = "Research";
            this.tp_Research.UseVisualStyleBackColor = true;
            // 
            // lvCitate
            // 
            this.lvCitate.Location = new System.Drawing.Point(193, 104);
            this.lvCitate.Name = "lvCitate";
            this.lvCitate.Size = new System.Drawing.Size(723, 433);
            this.lvCitate.TabIndex = 7;
            this.lvCitate.UseCompatibleStateImageBehavior = false;
            this.lvCitate.View = System.Windows.Forms.View.List;
            // 
            // lblRDesc
            // 
            this.lblRDesc.AutoSize = true;
            this.lblRDesc.Location = new System.Drawing.Point(190, 88);
            this.lblRDesc.Name = "lblRDesc";
            this.lblRDesc.Size = new System.Drawing.Size(68, 13);
            this.lblRDesc.TabIndex = 6;
            this.lblRDesc.Text = "Research By";
            // 
            // lbxFacArea
            // 
            this.lbxFacArea.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lbxFacArea.FormattingEnabled = true;
            this.lbxFacArea.Location = new System.Drawing.Point(17, 104);
            this.lbxFacArea.Name = "lbxFacArea";
            this.lbxFacArea.Size = new System.Drawing.Size(146, 351);
            this.lbxFacArea.TabIndex = 4;
            this.lbxFacArea.SelectedIndexChanged += new System.EventHandler(this.lbxFacArea_SelectedIndexChanged);
            // 
            // btnRSwitch
            // 
            this.btnRSwitch.Location = new System.Drawing.Point(37, 514);
            this.btnRSwitch.Name = "btnRSwitch";
            this.btnRSwitch.Size = new System.Drawing.Size(100, 23);
            this.btnRSwitch.TabIndex = 3;
            this.btnRSwitch.Text = "By Interest Area";
            this.btnRSwitch.UseVisualStyleBackColor = true;
            this.btnRSwitch.Click += new System.EventHandler(this.btnRSwitch_Click);
            // 
            // lblReTitle
            // 
            this.lblReTitle.AutoSize = true;
            this.lblReTitle.Location = new System.Drawing.Point(376, 41);
            this.lblReTitle.Name = "lblReTitle";
            this.lblReTitle.Size = new System.Drawing.Size(183, 13);
            this.lblReTitle.TabIndex = 0;
            this.lblReTitle.Text = "Faculty Research: Lookup by Faculty";
            // 
            // tp_Resources
            // 
            this.tp_Resources.Controls.Add(this.tbAbroad);
            this.tp_Resources.Controls.Add(this.lblSub);
            this.tp_Resources.Controls.Add(this.btnCoop);
            this.tp_Resources.Controls.Add(this.btnSAm);
            this.tp_Resources.Controls.Add(this.btnSS);
            this.tp_Resources.Controls.Add(this.lblFm);
            this.tp_Resources.Controls.Add(this.lblTL);
            this.tp_Resources.Controls.Add(this.lblSAb);
            this.tp_Resources.Controls.Add(this.lblRTitle);
            this.tp_Resources.Location = new System.Drawing.Point(4, 22);
            this.tp_Resources.Name = "tp_Resources";
            this.tp_Resources.Padding = new System.Windows.Forms.Padding(3);
            this.tp_Resources.Size = new System.Drawing.Size(936, 569);
            this.tp_Resources.TabIndex = 6;
            this.tp_Resources.Text = "Resources";
            this.tp_Resources.UseVisualStyleBackColor = true;
            // 
            // tbAbroad
            // 
            this.tbAbroad.BackColor = System.Drawing.SystemColors.Window;
            this.tbAbroad.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbAbroad.Location = new System.Drawing.Point(480, 163);
            this.tbAbroad.Multiline = true;
            this.tbAbroad.Name = "tbAbroad";
            this.tbAbroad.ReadOnly = true;
            this.tbAbroad.Size = new System.Drawing.Size(216, 152);
            this.tbAbroad.TabIndex = 7;
            // 
            // lblSub
            // 
            this.lblSub.AutoSize = true;
            this.lblSub.Location = new System.Drawing.Point(311, 61);
            this.lblSub.Name = "lblSub";
            this.lblSub.Size = new System.Drawing.Size(40, 13);
            this.lblSub.TabIndex = 6;
            this.lblSub.Text = "subtitle";
            // 
            // btnCoop
            // 
            this.btnCoop.Location = new System.Drawing.Point(30, 110);
            this.btnCoop.Name = "btnCoop";
            this.btnCoop.Size = new System.Drawing.Size(169, 119);
            this.btnCoop.TabIndex = 5;
            this.btnCoop.Text = "coop";
            this.btnCoop.UseVisualStyleBackColor = true;
            // 
            // btnSAm
            // 
            this.btnSAm.Location = new System.Drawing.Point(30, 281);
            this.btnSAm.Name = "btnSAm";
            this.btnSAm.Size = new System.Drawing.Size(169, 119);
            this.btnSAm.TabIndex = 4;
            this.btnSAm.Text = "ambass";
            this.btnSAm.UseVisualStyleBackColor = true;
            // 
            // btnSS
            // 
            this.btnSS.Location = new System.Drawing.Point(248, 281);
            this.btnSS.Name = "btnSS";
            this.btnSS.Size = new System.Drawing.Size(169, 119);
            this.btnSS.TabIndex = 3;
            this.btnSS.Text = "services";
            this.btnSS.UseVisualStyleBackColor = true;
            // 
            // lblFm
            // 
            this.lblFm.AutoSize = true;
            this.lblFm.Location = new System.Drawing.Point(761, 94);
            this.lblFm.Name = "lblFm";
            this.lblFm.Size = new System.Drawing.Size(32, 13);
            this.lblFm.TabIndex = 1;
            this.lblFm.Text = "forms";
            // 
            // lblTL
            // 
            this.lblTL.AutoSize = true;
            this.lblTL.Location = new System.Drawing.Point(477, 422);
            this.lblTL.Name = "lblTL";
            this.lblTL.Size = new System.Drawing.Size(28, 13);
            this.lblTL.TabIndex = 1;
            this.lblTL.Text = "tutor";
            // 
            // lblSAb
            // 
            this.lblSAb.AutoSize = true;
            this.lblSAb.Location = new System.Drawing.Point(311, 163);
            this.lblSAb.Name = "lblSAb";
            this.lblSAb.Size = new System.Drawing.Size(40, 13);
            this.lblSAb.TabIndex = 1;
            this.lblSAb.Text = "abroad";
            // 
            // lblRTitle
            // 
            this.lblRTitle.AutoSize = true;
            this.lblRTitle.Location = new System.Drawing.Point(410, 39);
            this.lblRTitle.Name = "lblRTitle";
            this.lblRTitle.Size = new System.Drawing.Size(23, 13);
            this.lblRTitle.TabIndex = 0;
            this.lblRTitle.Text = "title";
            // 
            // tp_News
            // 
            this.tp_News.Controls.Add(this.vsbNews);
            this.tp_News.Controls.Add(this.tbNDesc);
            this.tp_News.Controls.Add(this.label2);
            this.tp_News.Controls.Add(this.lblNDate);
            this.tp_News.Controls.Add(this.lblNTitle);
            this.tp_News.Location = new System.Drawing.Point(4, 22);
            this.tp_News.Name = "tp_News";
            this.tp_News.Padding = new System.Windows.Forms.Padding(3);
            this.tp_News.Size = new System.Drawing.Size(936, 569);
            this.tp_News.TabIndex = 7;
            this.tp_News.Text = "News";
            this.tp_News.UseVisualStyleBackColor = true;
            // 
            // vsbNews
            // 
            this.vsbNews.Location = new System.Drawing.Point(780, 54);
            this.vsbNews.Name = "vsbNews";
            this.vsbNews.Size = new System.Drawing.Size(17, 388);
            this.vsbNews.TabIndex = 4;
            this.vsbNews.Scroll += new System.Windows.Forms.ScrollEventHandler(this.vsbNews_Scroll);
            // 
            // tbNDesc
            // 
            this.tbNDesc.BackColor = System.Drawing.SystemColors.Window;
            this.tbNDesc.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbNDesc.Location = new System.Drawing.Point(52, 185);
            this.tbNDesc.Multiline = true;
            this.tbNDesc.Name = "tbNDesc";
            this.tbNDesc.ReadOnly = true;
            this.tbNDesc.Size = new System.Drawing.Size(673, 257);
            this.tbNDesc.TabIndex = 3;
            this.tbNDesc.Text = "desc";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(356, 36);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "News & Events";
            // 
            // lblNDate
            // 
            this.lblNDate.AutoSize = true;
            this.lblNDate.Location = new System.Drawing.Point(49, 144);
            this.lblNDate.Name = "lblNDate";
            this.lblNDate.Size = new System.Drawing.Size(35, 13);
            this.lblNDate.TabIndex = 1;
            this.lblNDate.Text = "label3";
            // 
            // lblNTitle
            // 
            this.lblNTitle.AutoSize = true;
            this.lblNTitle.Location = new System.Drawing.Point(49, 99);
            this.lblNTitle.Name = "lblNTitle";
            this.lblNTitle.Size = new System.Drawing.Size(35, 13);
            this.lblNTitle.TabIndex = 0;
            this.lblNTitle.Text = "label2";
            // 
            // tp_Footer
            // 
            this.tp_Footer.Controls.Add(this.lblCopyHtml);
            this.tp_Footer.Controls.Add(this.lblCopyright);
            this.tp_Footer.Controls.Add(this.lblTAuthor);
            this.tp_Footer.Controls.Add(this.llblLab);
            this.tp_Footer.Controls.Add(this.llblSupport);
            this.tp_Footer.Controls.Add(this.llblAbout);
            this.tp_Footer.Controls.Add(this.llblApply);
            this.tp_Footer.Controls.Add(this.lblTweet);
            this.tp_Footer.Controls.Add(this.lblSTitle);
            this.tp_Footer.Location = new System.Drawing.Point(4, 22);
            this.tp_Footer.Name = "tp_Footer";
            this.tp_Footer.Padding = new System.Windows.Forms.Padding(3);
            this.tp_Footer.Size = new System.Drawing.Size(936, 569);
            this.tp_Footer.TabIndex = 8;
            this.tp_Footer.Text = "Footer";
            this.tp_Footer.UseVisualStyleBackColor = true;
            // 
            // lblCopyHtml
            // 
            this.lblCopyHtml.AutoSize = true;
            this.lblCopyHtml.Location = new System.Drawing.Point(37, 435);
            this.lblCopyHtml.Name = "lblCopyHtml";
            this.lblCopyHtml.Size = new System.Drawing.Size(37, 13);
            this.lblCopyHtml.TabIndex = 8;
            this.lblCopyHtml.Text = "HTML";
            // 
            // lblCopyright
            // 
            this.lblCopyright.AutoSize = true;
            this.lblCopyright.Location = new System.Drawing.Point(376, 385);
            this.lblCopyright.Name = "lblCopyright";
            this.lblCopyright.Size = new System.Drawing.Size(51, 13);
            this.lblCopyright.TabIndex = 7;
            this.lblCopyright.Text = "Copyright";
            // 
            // lblTAuthor
            // 
            this.lblTAuthor.AutoSize = true;
            this.lblTAuthor.Location = new System.Drawing.Point(37, 100);
            this.lblTAuthor.Name = "lblTAuthor";
            this.lblTAuthor.Size = new System.Drawing.Size(37, 13);
            this.lblTAuthor.TabIndex = 6;
            this.lblTAuthor.Text = "author";
            // 
            // llblLab
            // 
            this.llblLab.AutoSize = true;
            this.llblLab.Location = new System.Drawing.Point(30, 297);
            this.llblLab.Name = "llblLab";
            this.llblLab.Size = new System.Drawing.Size(44, 13);
            this.llblLab.TabIndex = 5;
            this.llblLab.TabStop = true;
            this.llblLab.Text = "Lab Hrs";
            this.llblLab.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llblLab_LinkClicked);
            // 
            // llblSupport
            // 
            this.llblSupport.AutoSize = true;
            this.llblSupport.Location = new System.Drawing.Point(30, 250);
            this.llblSupport.Name = "llblSupport";
            this.llblSupport.Size = new System.Drawing.Size(44, 13);
            this.llblSupport.TabIndex = 4;
            this.llblSupport.TabStop = true;
            this.llblSupport.Text = "Support";
            this.llblSupport.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llblSupport_LinkClicked);
            // 
            // llblAbout
            // 
            this.llblAbout.AutoSize = true;
            this.llblAbout.Location = new System.Drawing.Point(30, 203);
            this.llblAbout.Name = "llblAbout";
            this.llblAbout.Size = new System.Drawing.Size(35, 13);
            this.llblAbout.TabIndex = 3;
            this.llblAbout.TabStop = true;
            this.llblAbout.Text = "About";
            this.llblAbout.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llblAbout_LinkClicked);
            // 
            // llblApply
            // 
            this.llblApply.AutoSize = true;
            this.llblApply.Location = new System.Drawing.Point(30, 156);
            this.llblApply.Name = "llblApply";
            this.llblApply.Size = new System.Drawing.Size(33, 13);
            this.llblApply.TabIndex = 2;
            this.llblApply.TabStop = true;
            this.llblApply.Text = "Apply";
            this.llblApply.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llblApply_LinkClicked);
            // 
            // lblTweet
            // 
            this.lblTweet.AutoSize = true;
            this.lblTweet.Location = new System.Drawing.Point(37, 72);
            this.lblTweet.Name = "lblTweet";
            this.lblTweet.Size = new System.Drawing.Size(37, 13);
            this.lblTweet.TabIndex = 1;
            this.lblTweet.Text = "Tweet";
            // 
            // lblSTitle
            // 
            this.lblSTitle.AutoSize = true;
            this.lblSTitle.Location = new System.Drawing.Point(393, 39);
            this.lblSTitle.Name = "lblSTitle";
            this.lblSTitle.Size = new System.Drawing.Size(59, 13);
            this.lblSTitle.TabIndex = 0;
            this.lblSTitle.Text = "Social Title";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(968, 612);
            this.Controls.Add(this.tcEverything);
            this.Name = "MainForm";
            this.Text = "MainForm";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tcEverything.ResumeLayout(false);
            this.tp_About.ResumeLayout(false);
            this.tp_About.PerformLayout();
            this.tp_Degrees.ResumeLayout(false);
            this.tp_Degrees.PerformLayout();
            this.tp_Minors.ResumeLayout(false);
            this.tp_Minors.PerformLayout();
            this.tp_Employ.ResumeLayout(false);
            this.tp_Employ.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCoop)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEmploy)).EndInit();
            this.tp_Ppl.ResumeLayout(false);
            this.tp_Ppl.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbPeople)).EndInit();
            this.tp_Research.ResumeLayout(false);
            this.tp_Research.PerformLayout();
            this.tp_Resources.ResumeLayout(false);
            this.tp_Resources.PerformLayout();
            this.tp_News.ResumeLayout(false);
            this.tp_News.PerformLayout();
            this.tp_Footer.ResumeLayout(false);
            this.tp_Footer.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tcEverything;
        private System.Windows.Forms.TabPage tp_About;
        private System.Windows.Forms.TabPage tp_Degrees;
        private System.Windows.Forms.TabPage tp_Minors;
        private System.Windows.Forms.TabPage tp_Employ;
        private System.Windows.Forms.TabPage tp_Ppl;
        private System.Windows.Forms.TabPage tp_Research;
        private System.Windows.Forms.TabPage tp_Resources;
        private System.Windows.Forms.TabPage tp_News;
        private System.Windows.Forms.TabPage tp_Footer;
        private System.Windows.Forms.Label lblDesc;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblQAuthor;
        private System.Windows.Forms.TextBox tbDesc;
        private System.Windows.Forms.TextBox tbQuote;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label ugTitle;
        private System.Windows.Forms.PictureBox pbPeople;
        private System.Windows.Forms.Label lblMTitle;
        private System.Windows.Forms.VScrollBar vsbNews;
        private System.Windows.Forms.TextBox tbNDesc;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblNDate;
        private System.Windows.Forms.Label lblNTitle;
        private System.Windows.Forms.Label lblCoopTitle;
        private System.Windows.Forms.TextBox tbCoopDesc;
        private System.Windows.Forms.Label lblETitle;
        private System.Windows.Forms.Label lblTweet;
        private System.Windows.Forms.Label lblSTitle;
        private System.Windows.Forms.LinkLabel llblLab;
        private System.Windows.Forms.LinkLabel llblSupport;
        private System.Windows.Forms.LinkLabel llblAbout;
        private System.Windows.Forms.LinkLabel llblApply;
        private System.Windows.Forms.Label lblTAuthor;
        private System.Windows.Forms.Label lblCopyHtml;
        private System.Windows.Forms.Label lblCopyright;
        private System.Windows.Forms.Label lblRTitle;
        private System.Windows.Forms.Label lblReTitle;
        private System.Windows.Forms.DataGridView dgvCoop;
        private System.Windows.Forms.Button btnNSA;
        private System.Windows.Forms.Button btnHCI;
        private System.Windows.Forms.Button btnIST;
        private System.Windows.Forms.Button btnCIT;
        private System.Windows.Forms.Button btnHCC;
        private System.Windows.Forms.Button btnWMC;
        private System.Windows.Forms.Button btnSwitch;
        private System.Windows.Forms.ListBox lbxPeople;
        private System.Windows.Forms.Label lblPTitle;
        private System.Windows.Forms.Label lblTagline;
        private System.Windows.Forms.Label lblUsername;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblTwitter;
        private System.Windows.Forms.Label lblWebsite;
        private System.Windows.Forms.Label lblOffice;
        private System.Windows.Forms.Label lblIntArea;
        private System.Windows.Forms.Label lblFbk;
        private System.Windows.Forms.Button btnTable;
        private System.Windows.Forms.DataGridView dgvEmploy;
        private System.Windows.Forms.Label lblTable;
        private System.Windows.Forms.Label lblC;
        private System.Windows.Forms.Label lblE;
        private System.Windows.Forms.Button btnRSwitch;
        private System.Windows.Forms.Label lblTL;
        private System.Windows.Forms.Label lblFm;
        private System.Windows.Forms.Label lblMName;
        private System.Windows.Forms.HScrollBar hsbMinors;
        private System.Windows.Forms.Label lblMin;
        private System.Windows.Forms.TextBox tbMDesc;
        private System.Windows.Forms.ListBox lbxCourses;
        private System.Windows.Forms.Label lblNote;
        private System.Windows.Forms.ListBox lbxFacArea;
        private System.Windows.Forms.Label lblSAb;
        private System.Windows.Forms.Label lblRDesc;
        private System.Windows.Forms.ListView lvCitate;
        private System.Windows.Forms.DataGridViewTextBoxColumn Employer;
        private System.Windows.Forms.DataGridViewTextBoxColumn Degree;
        private System.Windows.Forms.DataGridViewTextBoxColumn City;
        private System.Windows.Forms.DataGridViewTextBoxColumn Term;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Title;
        private System.Windows.Forms.DataGridViewTextBoxColumn StartDate;
        private System.Windows.Forms.TextBox tbCareers;
        private System.Windows.Forms.TextBox tbEmployers;
        private System.Windows.Forms.TextBox tbEmployDesc;
        private System.Windows.Forms.Label lblCert;
        private System.Windows.Forms.Label lblGrad;
        private System.Windows.Forms.Button btnSS;
        private System.Windows.Forms.Button btnCoop;
        private System.Windows.Forms.Button btnSAm;
        private System.Windows.Forms.Label lblSub;
        private System.Windows.Forms.TextBox tbAbroad;
    }
}

