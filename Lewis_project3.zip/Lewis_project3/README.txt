Alexa Lewis

I believe I excelled in using more tools other than buttons and labels.
Scroll bars were beneficial and were not used in class
Tried to make use of making a new form with classes that had the same format to keep the consistency of 
layout design