﻿namespace project3
{
    partial class DegreesInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblDegree = new System.Windows.Forms.Label();
            this.lblDTitle = new System.Windows.Forms.Label();
            this.tbDesc = new System.Windows.Forms.TextBox();
            this.lblConcent = new System.Windows.Forms.Label();
            this.lblCertif = new System.Windows.Forms.Label();
            this.lbxConcent = new System.Windows.Forms.ListBox();
            this.lbxCertif = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // lblDegree
            // 
            this.lblDegree.AutoSize = true;
            this.lblDegree.Location = new System.Drawing.Point(24, 34);
            this.lblDegree.Name = "lblDegree";
            this.lblDegree.Size = new System.Drawing.Size(35, 13);
            this.lblDegree.TabIndex = 0;
            this.lblDegree.Text = "label1";
            // 
            // lblDTitle
            // 
            this.lblDTitle.AutoSize = true;
            this.lblDTitle.Location = new System.Drawing.Point(364, 86);
            this.lblDTitle.Name = "lblDTitle";
            this.lblDTitle.Size = new System.Drawing.Size(35, 13);
            this.lblDTitle.TabIndex = 1;
            this.lblDTitle.Text = "label1";
            // 
            // tbDesc
            // 
            this.tbDesc.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbDesc.Location = new System.Drawing.Point(27, 119);
            this.tbDesc.Multiline = true;
            this.tbDesc.Name = "tbDesc";
            this.tbDesc.Size = new System.Drawing.Size(742, 50);
            this.tbDesc.TabIndex = 2;
            // 
            // lblConcent
            // 
            this.lblConcent.AutoSize = true;
            this.lblConcent.Location = new System.Drawing.Point(122, 256);
            this.lblConcent.Name = "lblConcent";
            this.lblConcent.Size = new System.Drawing.Size(72, 13);
            this.lblConcent.TabIndex = 5;
            this.lblConcent.Text = "Concetrations";
            // 
            // lblCertif
            // 
            this.lblCertif.AutoSize = true;
            this.lblCertif.Location = new System.Drawing.Point(558, 256);
            this.lblCertif.Name = "lblCertif";
            this.lblCertif.Size = new System.Drawing.Size(105, 13);
            this.lblCertif.TabIndex = 6;
            this.lblCertif.Text = "Available Certificates";
            // 
            // lbxConcent
            // 
            this.lbxConcent.FormattingEnabled = true;
            this.lbxConcent.Location = new System.Drawing.Point(27, 289);
            this.lbxConcent.Name = "lbxConcent";
            this.lbxConcent.Size = new System.Drawing.Size(320, 121);
            this.lbxConcent.TabIndex = 7;
            // 
            // lbxCertif
            // 
            this.lbxCertif.FormattingEnabled = true;
            this.lbxCertif.Location = new System.Drawing.Point(449, 289);
            this.lbxCertif.Name = "lbxCertif";
            this.lbxCertif.Size = new System.Drawing.Size(320, 121);
            this.lbxCertif.TabIndex = 8;
            // 
            // DegreesInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lbxCertif);
            this.Controls.Add(this.lbxConcent);
            this.Controls.Add(this.lblCertif);
            this.Controls.Add(this.lblConcent);
            this.Controls.Add(this.tbDesc);
            this.Controls.Add(this.lblDTitle);
            this.Controls.Add(this.lblDegree);
            this.Name = "DegreesInfo";
            this.Text = "DegreesInfo";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblDegree;
        private System.Windows.Forms.Label lblDTitle;
        private System.Windows.Forms.TextBox tbDesc;
        private System.Windows.Forms.Label lblConcent;
        private System.Windows.Forms.Label lblCertif;
        private System.Windows.Forms.ListBox lbxConcent;
        private System.Windows.Forms.ListBox lbxCertif;
    }
}