﻿using Newtonsoft.Json.Linq;
using RESTUtility;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project3
{
    public partial class MainForm : Form
    {
        //declare vars/objects
        About about;
        Degrees degrees;
        Employment employment;
        Footer footer;
        Minors minors;
        News news;
        People people;
        Research research;
        Resources resources;

        //declare other forms
        Form DegreesInfo;
        DegreesInfo dgi;


        //declare our REST object(s)
        REST rj = new REST("http://ist.rit.edu/api");

        public MainForm()
        {
            InitializeComponent();
            dgi = new DegreesInfo();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //get the /about/
            string jsonAbout = rj.getRestJSON("/about/");
            //Console.WriteLine(jsonAbout);
            //cast it to an object
            about = JToken.Parse(jsonAbout).ToObject<About>();

            //put out some data...
            lblTitle.Text = about.title;
            tbDesc.Text = about.description;
            tbQuote.Text = about.quote;
            lblQAuthor.Text = about.quoteAuthor;

            //degrees
            displayDegrees();

            //minors
            displayMinors();

            //people
            getPeople();

            //employment
            displayEmployment();

            //research
            displayResearch();

            //resources
            displayResources();

            //news
            displayNews();

            //footer
            displayFooter();

            //linkLabel1.Tag = resources.coopEnrollment.RITJobZoneGuidelink;
        }

        #region degrees
        public void displayDegrees()
        {
            //get the /degrees/
            string jsonDegrees = rj.getRestJSON("/degrees/");
            degrees = JToken.Parse(jsonDegrees).ToObject<Degrees>();


            //undergrad
            btnWMC.Click += new EventHandler(MyButtons);
            btnHCC.Click += new EventHandler(MyButtons);
            btnCIT.Click += new EventHandler(MyButtons);


            //grad 
            btnNSA.Click += new EventHandler(MyButtons);
            btnHCI.Click += new EventHandler(MyButtons);
            btnIST.Click += new EventHandler(MyButtons);
        }

        void MyButtons(object sender, EventArgs e)
        {
            string btnTxt = ((Button)sender).Text;
            List<Undergraduate> ugs = degrees.undergraduate;
            List<Graduate> gs = degrees.graduate;

            switch (btnTxt)
            {
                //ugrads
                case "WMC":
                    dgi.setLabel(ugs[0].degreeName, 1);
                    dgi.setLabel(ugs[0].title, 2);
                    dgi.setLabel(ugs[0].description, 3);
                    //add concentrations
                    foreach(string con in ugs[0].concentrations)
                    {
                        dgi.addToListConc(con);
                    }
                    dgi.Show();
                    break;
                case "HCC":
                    dgi.setLabel(ugs[1].degreeName, 1);
                    dgi.setLabel(ugs[1].title, 2);
                    dgi.setLabel(ugs[1].description, 3);
                    //add concentrations
                    foreach (string con in ugs[1].concentrations)
                    {
                        dgi.addToListConc(con);
                    }
                    dgi.Show();
                    break;
                case "CIT":
                    dgi.setLabel(ugs[2].degreeName, 1);
                    dgi.setLabel(ugs[2].title, 2);
                    dgi.setLabel(ugs[2].description, 3);
                    //add concentrations
                    foreach (string con in ugs[2].concentrations)
                    {
                        dgi.addToListConc(con);
                    }
                    dgi.Show();
                    break;

                //grads
                case "NSA":
                    dgi.setLabel(gs[0].degreeName, 1);
                    dgi.setLabel(gs[0].title, 2);
                    dgi.setLabel(gs[0].description, 3);
                    //add concentrations
                    foreach (string con in gs[0].concentrations)
                    {
                        dgi.addToListConc(con);
                    }
                    //add available certificates
                    foreach (string cert in gs[0].availableCertificates)
                    {
                        dgi.addToListCert(cert);
                    }
                    dgi.Show();
                    break;
                case "HCI":
                    dgi.setLabel(gs[1].degreeName, 1);
                    dgi.setLabel(gs[1].title, 2);
                    dgi.setLabel(gs[1].description, 3);
                    //add concentrations
                    foreach (string con in gs[1].concentrations)
                    {
                        dgi.addToListConc(con);
                    }
                    //add available certificates
                    foreach (string cert in gs[1].availableCertificates)
                    {
                        dgi.addToListCert(cert);
                    }
                    dgi.Show();
                    break;
                case "IST":
                    dgi.setLabel(gs[2].degreeName, 1);
                    dgi.setLabel(gs[2].title, 2);
                    dgi.setLabel(gs[2].description, 3);
                    //add concentrations
                    foreach (string con in gs[2].concentrations)
                    {
                        dgi.addToListConc(con);
                    }
                    //add available certificates
                    foreach (string cert in gs[2].availableCertificates)
                    {
                        dgi.addToListCert(cert);
                    }
                    dgi.Show();
                    break;
            }


        }
        #endregion

        #region minors
        public void displayMinors()
        {
            //get the /minors/
            string jsonMinors = rj.getRestJSON("/minors/");
            minors = JToken.Parse(jsonMinors).ToObject<Minors>();

            List<UgMinor> umin = minors.UgMinors;
            //same with vertical scroll bar was showing labels when loaded but still workswhen scrolling
            //set first ones from list
            lblMName.Text = umin[0].name;
            lblMin.Text = umin[0].title;
            tbMDesc.Text = umin[0].description;
            List<string> crs = umin[0].courses;
            foreach(string c in crs)
            {
                lbxCourses.Items.Add(c);
            }
            lblNote.Text = umin[0].note;
        }

        private void hScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            //sets the maximum value of scroll bar to the size of the list
            hsbMinors.Maximum = minors.UgMinors.Capacity;
            int num = hsbMinors.Value;

            //dump data; will change as the scroll
            List<UgMinor> umin = minors.UgMinors;
            lblMName.Text = umin[num].name;
            lblMin.Text = umin[num].title;
            tbMDesc.Text = umin[num].description;

            List<string> crs = umin[num].courses;
            lbxCourses.Items.Clear();
            foreach (string c in crs)
            {
                lbxCourses.Items.Add(c);
            }
            lblNote.Text = umin[num].note;
        }
        #endregion

        #region people
        public void getPeople()
        {
            //get the /people/
            string jsonPeople = rj.getRestJSON("/people/");
            people = JToken.Parse(jsonPeople).ToObject<People>();

            //sets the list to faculty by default
            btnSwitch.Text = "Faculty";

            List<Faculty> facs = people.faculty;

            foreach (Faculty fac in facs)
            {
                lbxPeople.Items.Add(fac.name);
            }
           
        }

        private void lbxPeople_SelectedIndexChanged(object sender, EventArgs e)
        {
            List<Faculty> facs = people.faculty;
            List<Staff> stafs = people.staff;

            string item = lbxPeople.SelectedItem.ToString();

            if (btnSwitch.Text.Equals("Faculty"))
            {
                for(int i = 0; i < facs.Count(); i++)
                {
                    if (item.Equals(facs[i].name))
                    {
                        pbPeople.ImageLocation = facs[i].imagePath;

                        lblName.Text = item;
                        lblUsername.Text = facs[i].username;
                        lblTagline.Text = facs[i].tagline;
                        lblPTitle.Text = facs[i].title;
                        lblIntArea.Text = facs[i].interestArea;
                        lblOffice.Text = facs[i].office;
                        lblWebsite.Text = facs[i].website;
                        lblTwitter.Text = facs[i].twitter;
                        lblFbk.Text = facs[i].facebook;
                    }
                }
            }
            else if (btnSwitch.Text.Equals("Staff"))
            {
                for(int j = 0; j < stafs.Count(); j++)
                {
                    if (item.Equals(stafs[j].name))
                    {
                        pbPeople.ImageLocation = stafs[j].imagePath;

                        lblName.Text = item;
                        lblUsername.Text = stafs[j].username;
                        lblTagline.Text = stafs[j].tagline;
                        lblPTitle.Text = stafs[j].title;
                        lblIntArea.Text = stafs[j].interestArea;
                        lblOffice.Text = stafs[j].office;
                        lblWebsite.Text = stafs[j].website;
                        lblTwitter.Text = stafs[j].twitter;
                        lblFbk.Text = stafs[j].facebook;
                    }
                }
            }

        }

        private void btnSwitch_Click(object sender, EventArgs e)
        {
            List<Faculty> facs = people.faculty;
            List<Staff> stafs = people.staff;

            //if the data type is of Faculty then switch text and the list to staff and vice versa
            //clear the list first then add the new list in
            lbxPeople.Items.Clear();

            if (btnSwitch.Text.Equals("Faculty"))
            {
                btnSwitch.Text = "Staff";
                foreach (Staff sta in stafs)
                {
                    lbxPeople.Items.Add(sta.name);
                }
            }          
            
            else if (btnSwitch.Text.Equals("Staff"))
            {
                btnSwitch.Text = "Faculty";
                foreach (Faculty fac in facs)
                {
                    lbxPeople.Items.Add(fac.name);
                }
            }
        }
        #endregion

        #region employment
        public void displayEmployment()
        {
            //get the /employment/
            string jsonEmployment = rj.getRestJSON("/employment/");
            employment = JToken.Parse(jsonEmployment).ToObject<Employment>();

            //intro
            lblMTitle.Text = employment.introduction.title;
            lblETitle.Text = employment.introduction.content[0].title;
            tbEmployDesc.Text = employment.introduction.content[0].description;
            lblCoopTitle.Text = employment.introduction.content[1].title;
            tbCoopDesc.Text = employment.introduction.content[1].description;

            addLabels();

            lblTable.Visible = false;
            //populating both tables but not making them visible first
            dgvCoop.Visible = false;
            for (int i = 0; i < employment.coopTable.coopInformation.Count; i++)
            {
                dgvCoop.Rows.Add();
                dgvCoop.Rows[i].Cells[0].Value = employment.coopTable.coopInformation[i].employer;
                dgvCoop.Rows[i].Cells[1].Value = employment.coopTable.coopInformation[i].degree;
                dgvCoop.Rows[i].Cells[2].Value = employment.coopTable.coopInformation[i].city;
                dgvCoop.Rows[i].Cells[3].Value = employment.coopTable.coopInformation[i].term;
            }

            dgvEmploy.Visible = false;
            for (int i = 0; i < employment.employmentTable.professionalEmploymentInformation.Count; i++)
            {
                dgvEmploy.Rows.Add();
                dgvEmploy.Rows[i].Cells[0].Value = employment.employmentTable.professionalEmploymentInformation[i].employer;
                dgvEmploy.Rows[i].Cells[1].Value = employment.employmentTable.professionalEmploymentInformation[i].degree;
                dgvEmploy.Rows[i].Cells[2].Value = employment.employmentTable.professionalEmploymentInformation[i].city;
                dgvEmploy.Rows[i].Cells[3].Value = employment.employmentTable.professionalEmploymentInformation[i].title;
                dgvEmploy.Rows[i].Cells[4].Value = employment.employmentTable.professionalEmploymentInformation[i].startDate;
            }
        }

        public void addLabels()
        {
            lblE.Text = employment.employers.title;
            lblC.Text = employment.careers.title;

            List<string> empList = employment.employers.employerNames;
            List<string> careList = employment.careers.careerNames;

            //adding employerNames
            int ey = lblE.Location.Y;
            foreach(string emp in empList)
            {
                Label lb = new Label();
                lb.Text = emp;
                lb.Location = new Point(740, ey + 10);
                tp_Employ.Controls.Add(lb);
            }

            //adding careerNames
            int cy = lblC.Location.Y;
            foreach (string car in careList)
            {
                Label lb = new Label();
                lb.Text = car;
                lb.Location = new Point(878, cy + 10);
                tp_Employ.Controls.Add(lb);
            }
        }

        private void btnTable_Click(object sender, EventArgs e)
        {
            lblTable.Visible = true;
            //shows everything associated with coop table
            if (btnTable.Text.Equals("Show Coop Table"))
            {
                lblTable.Text = employment.coopTable.title;
                dgvEmploy.Visible = false;
                dgvCoop.Visible = true;
                btnTable.Text = "Show Employment Table";
            }
            //shows everything associated with employment table
            else if (btnTable.Text.Equals("Show Employment Table"))
            {
                lblTable.Text = employment.employmentTable.title;
                dgvCoop.Visible = false;
                dgvEmploy.Visible = true;
                btnTable.Text = "Show Coop Table";
            }
        }
        #endregion


        #region research
        public void displayResearch()
        {
            //pbAreas.Click += new EventHandler(MyPBClick);

            //get the /research/
            string jsonResearch = rj.getRestJSON("/research/");
            research = JToken.Parse(jsonResearch).ToObject<Research>();

            //add citations to listbox for each faculty
            List<ByFaculty> bFac = research.byFaculty;
            for (int i = 0; i < bFac.Count; i++)
            {
                foreach (ByFaculty bf in bFac)
                {
                    lbxCitate.Items.Add(bf.citations);
                }
            }

            /*
             * Attempted to dynamically create items to form
             * int x = 35;
            int y = 50;
            for (int i = 0; i < bInt.Count; i++)
            {

                Button btn = new Button();
                btn.Text = bInt[i].areaName;
                btn.Location = new Point(x + 5, y + 5);
                tp_Research.Controls.Add(btn);
            }

            for (int i = 0; i < bFac.Count; i++)
            {
                PictureBox pb = new PictureBox();
                pb.Text = bFac[i].facultyName;
                pb.ImageLocation = GetImagePath(bFac[i].facultyName);
                //pb.Location = new Point();
                tp_Research.Controls.Add(pb);

            }*/
        }

        private void btnRSwitch_Click(object sender, EventArgs e)
        {

            if (btnRSwitch.Text.Equals("By Faculty"))
            {
                lblReTitle.Text = "Faculty Research: Lookup by Faculty";
                lbxCitate.Items.Clear();
                List<ByInterestArea> bInt = research.byInterestArea;
                for (int i = 0; i < bInt.Count; i++)
                {
                    foreach (ByInterestArea bia in bInt)
                    {
                        lbxCitate.Items.Add(bia.citations);
                    }
                }
                btnRSwitch.Text = "By Interest Area";
            }
            else if(btnRSwitch.Text.Equals("By Interest Area"))
            {
                lblReTitle.Text = "Faculty Research: Areas of Interest";
                lbxCitate.Items.Clear();
                List<ByFaculty> bFac = research.byFaculty;
                for (int i = 0; i < bFac.Count; i++)
                {
                    foreach (ByFaculty bf in bFac)
                    {
                        lbxCitate.Items.Add(bf.citations);
                    }
                }
                btnRSwitch.Text = "By Faculty";
            }
        }

        public string GetImagePath(string fname)
        {
            List<Faculty> facult = people.faculty;
            string path = "";
            for (int i = 0; i < facult.Count(); i++)
            {
                if (fname.Equals(facult[i].name))
                {
                     path = facult[i].imagePath;
                }
            }
            return path;
        }
        #endregion



        public void displayResources()
        {
            //get the /resources/
            string jsonResources = rj.getRestJSON("/resources/");
            resources = JToken.Parse(jsonResources).ToObject<Resources>();

            lblRTitle.Text = resources.title;

            lblSAb.Text = resources.studyAbroad.title;
            lblSAm.Text = resources.studentAmbassadors.title;
            lblSS.Text = resources.studentServices.title;
            lblTL.Text = resources.tutorsAndLabInformation.title;
        }

        #region displaynews
        public void displayNews()
        {
            //get the /news/
            string jsonNews = rj.getRestJSON("/news/");
            news = JToken.Parse(jsonNews).ToObject<News>();

            List<Older> oldNews = news.older;

            //sets the labels to show the latest news
            lblNTitle.Text = oldNews[0].title;
            lblNDate.Text = oldNews[0].date;
            tbNDesc.Text = oldNews[0].description;
        }
        
        /**
         * Vertical scroll bar has values which match the indices of the news list. As you scroll the texts title, date, and 
         * description are set to that index of the list
         */
        private void vsbNews_Scroll(object sender, ScrollEventArgs e)
        {
            List<Older> oldNews = news.older;

            //sets the maximum value of scroll bar to the size of the list
            vsbNews.Maximum = news.older.Capacity;
            int article = vsbNews.Value;

            //as you scroll the news with be replaced with the older ones
            lblNTitle.Text = oldNews[article].title;
            lblNDate.Text = oldNews[article].date;
            tbNDesc.Text = oldNews[article].description;

        }
        #endregion

        #region displayFooter
        public void displayFooter()
        {
            //get the /footer/
            string jsonFooter = rj.getRestJSON("/footer/");
            footer = JToken.Parse(jsonFooter).ToObject<Footer>();

            //social
            lblSTitle.Text = footer.social.title;
            lblTweet.Text = footer.social.tweet;
            lblTAuthor.Text = footer.social.by;
            
            //facebook and twitter icons

            //quick links
            List<QuickLink> qLinks = footer.quickLinks;
            llblApply.Text = qLinks[0].title;
            llblAbout.Text = qLinks[1].title;
            llblSupport.Text = qLinks[2].title;
            llblLab.Text = qLinks[3].title;

            //copyright
            lblCopyright.Text = footer.copyright.title;
            lblCopyHtml.Text = footer.copyright.html;

        }

        private void VisitLink(LinkLabel llbl, string href)
        {
            llbl.LinkVisited = true;

            //go to url
            Process.Start(href);
        }

        private void LinkClicks(object sender, LinkLabelLinkClickedEventArgs e)
        {
            LinkLabel llbl = sender as LinkLabel;
        }

        /*Tried to think of common function for clicking link label events since each of function is doing the same thing */
        private void llblApply_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //quick links
            List<QuickLink> qLinks = footer.quickLinks;

            try
            {
                VisitLink(llblApply, qLinks[0].href);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unable to open link that was clicked.");
            }
        }

        private void llblAbout_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //quick links
            List<QuickLink> qLinks = footer.quickLinks;

            try
            {
                VisitLink(llblAbout, qLinks[1].href);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unable to open link that was clicked.");
            }
        }

        private void llblSupport_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //quick links
            List<QuickLink> qLinks = footer.quickLinks;

            try
            {
                VisitLink(llblSupport, qLinks[2].href);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unable to open link that was clicked.");
            }
        }

        private void llblLab_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //quick links
            List<QuickLink> qLinks = footer.quickLinks;

            try
            {
                VisitLink(llblLab, qLinks[3].href);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unable to open link that was clicked.");
            }
        }

        #endregion

        
    }
}
