﻿using RESTUtility;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project3
{
    public partial class DegreesInfo : Form
    {
        Degrees degrees;
        REST rj = new REST("http://ist.rit.edu/api");

        public DegreesInfo()
        {
            InitializeComponent();
        }

        public void setLabel(string name, int num)
        {
            if(num == 1)
            {
                lblDegree.Text = name;
            }
            else if(num == 2)
            {
                lblDTitle.Text = name;
            }
            else if (num == 3)
            {
                tbDesc.Text = name;
            }
            
        }

        public void addToListConc(string item)
        {
            //if a list already exists
            lbxConcent.Items.Clear();
            
            lbxConcent.Items.Add(item);
            
        }

        public void addToListCert(string item)
        {
            //if a list already exists
            lbxCertif.Items.Clear();

            lbxCertif.Items.Add(item);

        }
    }
}
