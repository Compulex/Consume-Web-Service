﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace RESTUtility
{
    public class REST
    {
        //define the baseUri
        private string baseUri;
        public REST(string bU)
        {
            this.baseUri = bU;
        }

        #region getRest
        public string getRestJSON(string uri)
        {
            string baseUri = "http://ist.rit.edu/api";
            //connect to the api
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(baseUri + uri);
            try
            {
                WebResponse response = request.GetResponse();
                using (Stream responseStream = response.GetResponseStream())
                {
                    StreamReader reader = new StreamReader(responseStream, Encoding.UTF8);
                    return reader.ReadToEnd();
                }
            }
            catch (WebException wex)
            {
                WebResponse err = wex.Response;
                using (Stream responseStream = err.GetResponseStream())
                {
                    StreamReader r = new StreamReader(responseStream, Encoding.UTF8);
                    string errortext = r.ReadToEnd();
                }
                throw;
            }
        }
        #endregion
    }
}
